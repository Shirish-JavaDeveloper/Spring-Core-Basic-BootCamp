package com.springboot.basic.service;

import com.springboot.basic.entity.Order;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class PaymentService {
    private static Logger logger = LoggerFactory.getLogger(PaymentService.class);
    private CreditCardPaymentService creditCardPaymentService;

    public PaymentService() {
        creditCardPaymentService = new CreditCardPaymentService();
    }

    public double makePayment(Order order){
        logger.info("Payment process started for "+order);
        return creditCardPaymentService.debitAmount(order.getAmount());
    }
}

